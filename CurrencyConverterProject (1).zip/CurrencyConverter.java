import javax.swing.*;
import java.awt.event.*;

public class CurrencyConverter {

    public static void main(String[] args) {
        // Create JFrame
        JFrame frame = new JFrame("Currency Converter");
        frame.setSize(400, 300);
        frame.setLayout(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Label and text field for amount
        JLabel amountLabel = new JLabel("Enter Amount (INR):");
        amountLabel.setBounds(30, 30, 150, 25);
        frame.add(amountLabel);

        JTextField amountField = new JTextField();
        amountField.setBounds(180, 30, 150, 25);
        frame.add(amountField);

        // Label and dropdown for target currency
        JLabel currencyLabel = new JLabel("Convert to:");
        currencyLabel.setBounds(30, 70, 150, 25);
        frame.add(currencyLabel);

        String[] currencies = {"USD", "EUR", "GBP", "JPY"};
        JComboBox<String> currencyBox = new JComboBox<>(currencies);
        currencyBox.setBounds(180, 70, 150, 25);
        frame.add(currencyBox);

        // Button to convert
        JButton convertButton = new JButton("Convert");
        convertButton.setBounds(130, 120, 100, 30);
        frame.add(convertButton);

        // Label to show result
        JLabel resultLabel = new JLabel("Converted Amount: ");
        resultLabel.setBounds(30, 170, 300, 25);
        frame.add(resultLabel);

        // Action listener for convert button
        convertButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    double amount = Double.parseDouble(amountField.getText());
                    String currency = (String) currencyBox.getSelectedItem();
                    double convertedAmount = 0;

                    switch (currency) {
                        case "USD":
                            convertedAmount = amount * 0.012;
                            break;
                        case "EUR":
                            convertedAmount = amount * 0.011;
                            break;
                        case "GBP":
                            convertedAmount = amount * 0.0095;
                            break;
                        case "JPY":
                            convertedAmount = amount * 1.65;
                            break;
                    }

                    resultLabel.setText("Converted Amount: " + convertedAmount + " " + currency);
                } catch (NumberFormatException ex) {
                    resultLabel.setText("Invalid amount! Please enter a number.");
                }
            }
        });

        // Make frame visible
        frame.setVisible(true);
    }
}